# WebDirectory CORE

## Comandes à faire :
1 - Mettre en place le `.env` à partir de `.env.temp`

2 - `docker compose up -d` DEPUIS CE REPERTOIR `/WebDir.core`

3 - `docker exec -it php_appli /bin/bash`

4 - `cd ../src`

5 - `composer install`

6 - `exit`