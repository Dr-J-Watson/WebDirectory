<?php

namespace WebDir\core\appli\core\services\personne;

interface PersonneServiceInterface{

    public function addPersonne(array $personne);
}